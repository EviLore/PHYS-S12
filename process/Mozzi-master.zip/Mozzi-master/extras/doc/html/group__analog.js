var group__analog =
[
    [ "adcDisconnectAllDigitalIns", "group__analog.html#ga5042e7c576dd0307be38eb70efdb69fe", null ],
    [ "adcReconnectAllDigitalIns", "group__analog.html#gabad497d1f8c8026e81849be0b65bf38f", null ],
    [ "disconnectDigitalIn", "group__analog.html#ga532fe99fe78e34d4e6ae0ae2c7528353", null ],
    [ "getAudioInput", "group__analog.html#ga3f15eb8d6694020d170ebcbedb645de7", null ],
    [ "mozziAnalogRead", "group__analog.html#gae9536bf35f6ea46a6938d5eb52b947c3", null ],
    [ "reconnectDigitalIn", "group__analog.html#ga26462e443299e8d39a520d4a838e00b7", null ],
    [ "setupFastAnalogRead", "group__analog.html#gae909f8857d71ed79f277ee024de52574", null ]
];