var struct_stereo_output =
[
    [ "StereoOutput", "struct_stereo_output.html#a21de1439b838982ab5cb6663bef94498", null ],
    [ "StereoOutput", "struct_stereo_output.html#a78371f79ab53e2b7c6ec5e0e04fc5062", null ],
    [ "clip", "struct_stereo_output.html#ac949f14e2d88f3c4e11986675addb228", null ],
    [ "l", "struct_stereo_output.html#a1f5572fce5164f49fc21d7a828fe04a8", null ],
    [ "r", "struct_stereo_output.html#aecd84b6725634f864349a668bdfdf653", null ]
];